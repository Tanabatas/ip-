---
name: "Bug反馈\U0001F605"
about: 发现了Bug？火速提交Issus！
title: "[Bug]我发现一个新的Bug:"
labels: bug
assignees: ''

---

<!--⚠️请认真填写下列问题，以便开发者能精确修复问题-->
<!--🐧您可以先在Issues中搜索相关问题，可能会更快的解决问题-->
<!--⚠️请勿删除这些提示-->

- 你的MOliGeek版本：
- 你的所使用的Python版本：
- 你是否使用的是原版MoliGeek呢：

它是如何出现的呢，请详细描述哦？
1. 
2. 
