__name__    = "moligeek"
__version__ = "1.1.1"
__author__   = "yourmoln"
__author_email__ = "yourmoln@outlook.com"
__url__     = "https://github.com/yourmoln/moligeek"
__description__ = "一款逐渐完善的python集成工具,努力为开发者提供最大的便利"
__license__ = "Apache 2.0"
__copyright__ = 'Copyright yourmoln'
